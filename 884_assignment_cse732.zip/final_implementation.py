import cv2
import numpy as np
import time
import random
from sklearn.cluster import DBSCAN
from typing import Tuple, List, Optional

class GeneticThresholdOptimizer:
    """
    GENETIC ALGORITHM FOR AUTOMATIC THRESHOLD OPTIMIZATION
    """
    
    def __init__(self, population_size=30, generations=15, mutation_rate=0.1):
        self.population_size = population_size
        self.generations = generations
        self.mutation_rate = mutation_rate
        self.crossover_rate = 0.8
        
        # Threshold ranges optimized for lane detection
        self.min_threshold = 20
        self.max_threshold = 200
        
        # Best solution tracking
        self.best_fitness_history = []
        self.best_solution = None
        self.best_fitness = float('-inf')
        
    def create_individual(self) -> Tuple[int, int]:
        """Create a random individual representing threshold pair"""
        low_threshold = random.randint(self.min_threshold, self.max_threshold // 2)
        high_threshold = random.randint(low_threshold + 10, self.max_threshold)
        return (low_threshold, high_threshold)
    
    def initialize_population(self) -> List[Tuple[int, int]]:
        """Initialize population of threshold pairs"""
        return [self.create_individual() for _ in range(self.population_size)]
    
    def fitness_function(self, individual: Tuple[int, int], image: np.ndarray) -> float:
        """
        FITNESS FUNCTION - Optimized for lane detection
        Evaluates threshold quality based on lane detection effectiveness
        """
        if image is None or image.size == 0:
            return -1000
            
        low_thresh, high_thresh = individual
        
        if low_thresh >= high_thresh or low_thresh < 10:
            return -1000
        
        try:
            # Apply preprocessing similar to EnhancedLaneDepartureWarning
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image
            blurred = cv2.GaussianBlur(gray, (5, 5), 0)
            
            # Apply region of interest (simplified version)
            height, width = gray.shape
            vertices = np.array([
                [(width * 0.1, height),
                 (width * 0.4, height * 0.6),
                 (width * 0.6, height * 0.6),
                 (width * 0.9, height)]
            ], dtype=np.int32)
            
            mask = np.zeros_like(gray)
            cv2.fillPoly(mask, [vertices[0]], (255,))
            roi_gray = cv2.bitwise_and(blurred, mask)
            
            # Apply Canny with these thresholds
            edges = cv2.Canny(roi_gray, low_thresh, high_thresh)
            
            # Calculate fitness components for lane detection
            edge_density = self._calculate_lane_edge_density(edges)
            connectivity = self._calculate_lane_connectivity(edges)
            line_quality = self._calculate_line_quality(edges)
            
            # Combined fitness for lane detection
            fitness = (
                0.4 * edge_density +      # 40% weight on appropriate edge density
                0.4 * connectivity +      # 40% weight on edge connectivity
                0.2 * line_quality        # 20% weight on line-like structures
            )
            
            return fitness
            
        except Exception as e:
            print(f"⚠️  Error in fitness function: {e}")
            return -1000
    
    def _calculate_lane_edge_density(self, edges: np.ndarray) -> float:
        """Calculate appropriate edge density for lane detection"""
        total_pixels = edges.shape[0] * edges.shape[1]
        edge_pixels = np.sum(edges > 0)
        density = edge_pixels / total_pixels
        
        # Optimal density for lane detection is around 2-8%
        optimal_density = 0.05
        penalty = abs(density - optimal_density) / optimal_density
        return max(0, 100 * (1 - penalty))
    
    def _calculate_lane_connectivity(self, edges: np.ndarray) -> float:
        """Calculate connectivity suitable for lane lines"""
        if np.sum(edges) == 0:
            return 0
        
        # Use morphological operations to find connected components
        kernel = np.ones((3, 3), np.uint8)
        connected = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)
        
        num_labels, labels = cv2.connectedComponents(connected)
        
        if num_labels <= 1:
            return 0
        
        # Prefer fewer, larger components (lane-like structures)
        component_sizes = []
        for i in range(1, num_labels):
            component_size = np.sum(labels == i)
            component_sizes.append(component_size)
        
        if not component_sizes:
            return 0
        
        # Reward larger components
        avg_component_size = np.mean(component_sizes)
        return min(avg_component_size / 50.0, 100.0)
    
    def _calculate_line_quality(self, edges: np.ndarray) -> float:
        """Calculate how well edges form line-like structures"""
        lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=20,
                               minLineLength=30, maxLineGap=10)
        
        if lines is None:
            return 0
        
        # Reward having some lines, but not too many (noise)
        num_lines = len(lines)
        if num_lines == 0:
            return 0
        elif num_lines <= 20:
            return min(num_lines * 5, 100)
        else:
            return max(0, 100 - (num_lines - 20) * 2)
    
    def selection(self, population: List[Tuple[int, int]], 
                  fitness_scores: List[float]) -> List[Tuple[int, int]]:
        """Tournament selection"""
        selected = []
        tournament_size = 3
        
        for _ in range(len(population)):
            tournament_indices = random.sample(range(len(population)), tournament_size)
            tournament_fitness = [fitness_scores[i] for i in tournament_indices]
            winner_index = tournament_indices[np.argmax(tournament_fitness)]
            selected.append(population[winner_index])
        
        return selected
    
    def crossover(self, parent1: Tuple[int, int], parent2: Tuple[int, int]) -> Tuple[Tuple[int, int], Tuple[int, int]]:
        """Crossover to create offspring"""
        if random.random() > self.crossover_rate:
            return parent1, parent2
        
        p1_low, p1_high = parent1
        p2_low, p2_high = parent2
        
        alpha = random.random()
        offspring1_low = int(alpha * p1_low + (1 - alpha) * p2_low)
        offspring1_high = int(alpha * p1_high + (1 - alpha) * p2_high)
        
        offspring2_low = int((1 - alpha) * p1_low + alpha * p2_low)
        offspring2_high = int((1 - alpha) * p1_high + alpha * p2_high)
        
        # Ensure valid threshold pairs
        offspring1_low = max(self.min_threshold, min(offspring1_low, offspring1_high - 10))
        offspring1_high = max(offspring1_low + 10, min(offspring1_high, self.max_threshold))
        
        offspring2_low = max(self.min_threshold, min(offspring2_low, offspring2_high - 10))
        offspring2_high = max(offspring2_low + 10, min(offspring2_high, self.max_threshold))
        
        return (offspring1_low, offspring1_high), (offspring2_low, offspring2_high)
    
    def mutate(self, individual: Tuple[int, int]) -> Tuple[int, int]:
        """Mutation operator"""
        if random.random() > self.mutation_rate:
            return individual
        
        low_thresh, high_thresh = individual
        
        if random.random() < 0.5:
            mutation_range = 15
            low_thresh += random.randint(-mutation_range, mutation_range)
            low_thresh = max(self.min_threshold, min(low_thresh, high_thresh - 10))
        else:
            mutation_range = 15
            high_thresh += random.randint(-mutation_range, mutation_range)
            high_thresh = max(low_thresh + 10, min(high_thresh, self.max_threshold))
        
        return (low_thresh, high_thresh)
    
    def evolve(self, image: np.ndarray, verbose: bool = False) -> Tuple[int, int]:
        """Main evolution process"""
        if verbose:
            print("🧬 Optimizing Canny thresholds with Genetic Algorithm...")
        
        population = self.initialize_population()
        
        for generation in range(self.generations):
            fitness_scores = [self.fitness_function(ind, image) for ind in population]
            
            best_idx = np.argmax(fitness_scores)
            generation_best_fitness = fitness_scores[best_idx]
            generation_best_individual = population[best_idx]
            
            if generation_best_fitness > self.best_fitness:
                self.best_fitness = generation_best_fitness
                self.best_solution = generation_best_individual
            
            self.best_fitness_history.append(self.best_fitness)
            
            if verbose and generation % 5 == 0:
                print(f"Gen {generation:2d}: Best={generation_best_fitness:.1f}, Thresholds={generation_best_individual}")
            
            selected = self.selection(population, fitness_scores)
            
            next_generation = []
            for i in range(0, len(selected), 2):
                parent1 = selected[i]
                parent2 = selected[(i + 1) % len(selected)]
                
                offspring1, offspring2 = self.crossover(parent1, parent2)
                offspring1 = self.mutate(offspring1)
                offspring2 = self.mutate(offspring2)
                
                next_generation.extend([offspring1, offspring2])
            
            population = next_generation[:self.population_size]
        
        if verbose:
            print(f"Optimal thresholds: {self.best_solution}")
        
        return self.best_solution


class EnhancedLaneDepartureWarning:
    """
    Enhanced Lane Departure Warning System with Kalman Filtering and Genetic Algorithm Optimization
    
    Processing Pipeline:
    1. Image preprocessing with color enhancement
    2. Shadow detection and mitigation 
    3. Adaptive Canny edge detection (optimized every 120th frame)
    4. Adaptive ROI based on vanishing point
    5. Hough transform line detection
    6. Line validation and filtering
    7. Kalman filter tracking
    8. Lane departure analysis
    """

    def __init__(self):
        # Image processing parameters (will be optimized by genetic algorithm)
        self.gaussian_kernel = 5
        self.canny_low = 50
        self.canny_high = 150
        self.shadow_threshold = 0.1

        # Hough transform parameters
        self.rho = 1
        self.theta = np.pi / 180
        self.threshold = 20
        self.min_line_length = 80
        self.max_line_gap = 50

        # Lane classification parameters
        self.min_lane_slope = 0.3
        self.max_lane_slope = 3.0

        # Kalman filter parameters
        self.kalman_dt = 1.0
        self.process_noise = 0.01
        self.measurement_noise = 0.1
        
        # Initialize Kalman filters for tracking
        self.left_lane_kalman = self.initialize_kalman_filter()
        self.right_lane_kalman = self.initialize_kalman_filter()
        
        # Genetic Algorithm Optimizer
        self.genetic_optimizer = GeneticThresholdOptimizer(
            population_size=20,  # Reduced for faster optimization
            generations=10,      # Reduced for real-time performance
            mutation_rate=0.1
        )
        
        # Frame counting for genetic algorithm optimization
        self.frame_count = 0
        self.optimization_interval = 120  # Optimize every 120 frames
        self.last_optimization_frame = 0

    def initialize_kalman_filter(self):
        """Initialize Kalman filter with state [m, c, dm, dc] for slope and intercept tracking"""
        kalman = cv2.KalmanFilter(4, 2)
        
        # State transition matrix F (constant velocity model)
        kalman.transitionMatrix = np.array([[1, 0, self.kalman_dt, 0],
                                          [0, 1, 0, self.kalman_dt],
                                          [0, 0, 1, 0],
                                          [0, 0, 0, 1]], dtype=np.float32)
        
        # Measurement matrix H
        kalman.measurementMatrix = np.array([[1, 0, 0, 0],
                                           [0, 1, 0, 0]], dtype=np.float32)
        
        # Process noise covariance Q
        kalman.processNoiseCov = self.process_noise * np.eye(4, dtype=np.float32)
        
        # Measurement noise covariance R
        kalman.measurementNoiseCov = self.measurement_noise * np.eye(2, dtype=np.float32)
        
        # Initial state estimate
        kalman.statePre = np.array([0, 0, 0, 0], dtype=np.float32)
        kalman.statePost = np.array([0, 0, 0, 0], dtype=np.float32)
        
        # Initial error covariance
        kalman.errorCovPre = np.eye(4, dtype=np.float32)
        kalman.errorCovPost = np.eye(4, dtype=np.float32)
        
        return kalman

    def optimize_canny_thresholds(self, image):
        """Optimize Canny thresholds using genetic algorithm"""
        if image is None or image.size == 0:
            print("⚠️  Cannot optimize: Invalid input image")
            return
            
        print(f"🧬 Frame {self.frame_count}: Running genetic algorithm optimization...")
        start_time = time.time()
        
        try:
            optimal_thresholds = self.genetic_optimizer.evolve(image, verbose=False)
            
            if optimal_thresholds:
                self.canny_low, self.canny_high = optimal_thresholds
                optimization_time = time.time() - start_time
                print(f"✅ Optimization complete in {optimization_time:.2f}s")
                print(f"   New thresholds: Low={self.canny_low}, High={self.canny_high}")
            else:
                print("⚠️  Optimization failed, keeping current thresholds")
        except Exception as e:
            print(f"❌ Optimization error: {e}")
            print("   Keeping current thresholds")

    def preprocess_image(self, image):
        """Enhanced preprocessing with color-based lane enhancement"""
        if image is None or image.size == 0:
            raise ValueError("Input image is None or empty")
        
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

        # Enhance white and yellow lane markings
        enhanced_gray = self.enhance_lane_markings(image, gray, hsv)

        # Apply Gaussian blur
        blur = cv2.GaussianBlur(enhanced_gray, (self.gaussian_kernel, self.gaussian_kernel), 0)

        return gray, enhanced_gray, blur

    def enhance_lane_markings(self, bgr_image, gray, hsv):
        """Color-based lane marking enhancement for white and yellow lanes"""
        # Create masks for white and yellow lane markings
        white_mask = self.create_white_lane_mask(bgr_image, hsv)
        yellow_mask = self.create_yellow_lane_mask(hsv)

        # Combine masks
        lane_mask = cv2.bitwise_or(white_mask, yellow_mask)

        # Clean up the mask with morphological operations
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        lane_mask = cv2.morphologyEx(lane_mask, cv2.MORPH_CLOSE, kernel)
        lane_mask = cv2.morphologyEx(lane_mask, cv2.MORPH_OPEN, kernel)

        # Enhance lane markings in grayscale image
        enhanced = gray.copy()
        enhanced[lane_mask > 0] = np.minimum(enhanced[lane_mask > 0] + 50, 255)

        return enhanced

    def create_white_lane_mask(self, bgr_image, hsv):
        """Create mask for white lane markings"""
        # White in BGR
        lower_white_bgr = np.array([180, 180, 180])
        upper_white_bgr = np.array([255, 255, 255])
        white_mask_bgr = cv2.inRange(bgr_image, lower_white_bgr, upper_white_bgr)

        # White in HSV
        lower_white_hsv = np.array([0, 0, 200])
        upper_white_hsv = np.array([180, 30, 255])
        white_mask_hsv = cv2.inRange(hsv, lower_white_hsv, upper_white_hsv)

        return cv2.bitwise_or(white_mask_bgr, white_mask_hsv)

    def create_yellow_lane_mask(self, hsv):
        """Create mask for yellow lane markings"""
        lower_yellow = np.array([15, 80, 100])
        upper_yellow = np.array([35, 255, 255])
        return cv2.inRange(hsv, lower_yellow, upper_yellow)

    def shadow_mitigation_hsv(self, image: np.ndarray) -> tuple:
        """
        Shadow detection and mitigation using HSV color space
        
        Implements:
        - NSVDI(i, j) = (S(i, j) - V(i, j)) / (S(i, j) + V(i, j))
        - Linear Correlation Correction (LCC)
        """
        # Convert to HSV
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        H, S, V = hsv[:, :, 0].astype(np.float32), hsv[:, :, 1].astype(np.float32), hsv[:, :, 2].astype(np.float32)
        
        # Normalized Saturation-Value Difference Index
        denominator = S + V
        denominator[denominator == 0] = 1e-10
        nsvdi = (S - V) / denominator
        
        # Binary shadow mask segmentation
        shadow_mask = nsvdi > self.shadow_threshold
        
        # Linear Correlation Correction for shadow regions
        corrected_image = image.copy().astype(np.float32)
        
        if np.any(shadow_mask):
            shadow_pixels = V[shadow_mask]
            non_shadow_pixels = V[~shadow_mask]
            
            if len(non_shadow_pixels) > 0 and len(shadow_pixels) > 0:
                mu_s = np.mean(shadow_pixels)
                sigma_s = np.std(shadow_pixels)
                mu_ns = np.mean(non_shadow_pixels)
                sigma_ns = np.std(non_shadow_pixels)
                
                if sigma_s > 0:
                    correction_factor = sigma_ns / sigma_s
                    V_corrected = V.copy()
                    V_corrected[shadow_mask] = (mu_ns - mu_s) + correction_factor * (V[shadow_mask] - mu_s)
                    
                    hsv_corrected = hsv.copy()
                    hsv_corrected[:, :, 2] = np.clip(V_corrected, 0, 255).astype(np.uint8)
                    corrected_image = cv2.cvtColor(hsv_corrected, cv2.COLOR_HSV2BGR)
        
        return corrected_image.astype(np.uint8), shadow_mask.astype(np.uint8)

    def canny_edge_detection(self, blurred_image, low_thresh=None, high_thresh=None):
        """Apply Canny edge detection with optimized thresholds"""
        if low_thresh is None:
            low_thresh = self.canny_low
        if high_thresh is None:
            high_thresh = self.canny_high

        return cv2.Canny(blurred_image, low_thresh, high_thresh)

    def adaptive_roi_vanishing_point(self, image):
        """Adaptive ROI based on vanishing point detection"""
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image

        # Initial edge detection for line detection
        edges = cv2.Canny(gray, 50, 150, apertureSize=3)

        # Detect lines using Hough Transform
        lines = cv2.HoughLines(edges, 1, np.pi/180, threshold=100)

        if lines is None or len(lines) < 2:
            height, width = image.shape[:2]
            vanishing_point = (width // 2, height // 2)
        else:
            max_lines = min(100, len(lines))
            lines = lines[:max_lines]
            vanishing_point = self.estimate_vanishing_point(lines, image.shape)

        # Create adaptive trapezoidal ROI
        roi_mask = self.create_adaptive_roi(image.shape, vanishing_point)

        return roi_mask, vanishing_point, edges

    def estimate_vanishing_point(self, lines: np.ndarray, image_shape: Tuple[int, int]) -> Tuple[int, int]:
        """Estimate vanishing point from line intersections using homogeneous coordinates"""
        height, width = image_shape[:2]
        intersections = []
        
        for i in range(len(lines)):
            for j in range(i + 1, len(lines)):
                rho1, theta1 = lines[i][0]
                rho2, theta2 = lines[j][0]
                
                # Convert polar to homogeneous line representation
                l1 = np.array([np.cos(theta1), np.sin(theta1), -rho1])
                l2 = np.array([np.cos(theta2), np.sin(theta2), -rho2])
                
                # Line intersection: v = l1 × l2
                v = np.cross(l1, l2)
                
                if abs(v[2]) > 1e-6:
                    x, y = int(v[0] / v[2]), int(v[1] / v[2])
                    
                    if 0 <= x <= width and 0 <= y <= height:
                        intersections.append((x, y))
        
        if not intersections:
            return (width // 2, height // 3)
        
        # Use DBSCAN clustering to find main cluster
        if len(intersections) > 1:
            intersections_array = np.array(intersections)
            clustering = DBSCAN(eps=10, min_samples=2).fit(intersections_array)
            
            labels = clustering.labels_
            if len(set(labels)) > 1 and -1 in labels:
                unique_labels, counts = np.unique(labels[labels != -1], return_counts=True)
                if len(unique_labels) > 0:
                    main_cluster_label = unique_labels[np.argmax(counts)]
                    cluster_points = intersections_array[labels == main_cluster_label]
                    vp = np.mean(cluster_points, axis=0).astype(int)
                    return tuple(vp)
        
        # Fallback: use median of all intersections
        intersections_array = np.array(intersections)
        vp = np.median(intersections_array, axis=0).astype(int)
        return tuple(vp)

    def create_adaptive_roi(self, image_shape, vanishing_point):
        """Create adaptive trapezoidal ROI based on vanishing point"""
        height, width = image_shape[:2]
        vx, vy = vanishing_point

        # Parameters for trapezoid
        h_offset = 50
        w_top = width // 8
        w_bottom = width // 2

        # Ensure vanishing point is reasonable
        vy = max(50, min(vy, height - 100))

        # Define trapezoid vertices
        top_left = (max(0, vx - w_top), max(0, vy + h_offset))
        top_right = (min(width, vx + w_top), max(0, vy + h_offset))
        bottom_left = (max(0, vx - w_bottom), height)
        bottom_right = (min(width, vx + w_bottom), height)

        # Create ROI mask
        roi_mask = np.zeros((height, width), dtype=np.uint8)
        roi_vertices = np.array([top_left, top_right, bottom_right, bottom_left], dtype=np.int32)
        cv2.fillPoly(roi_mask, [roi_vertices], 255)

        return roi_mask

    def region_of_interest(self, image):
        """Apply adaptive ROI based on vanishing point detection"""
        start = time.time()
        roi_mask, vanishing_point, edges_for_vp = self.adaptive_roi_vanishing_point(image)

        # Apply ROI mask
        if len(image.shape) == 3:
            masked_image = cv2.bitwise_and(image, image, mask=roi_mask)
        else:
            masked_image = cv2.bitwise_and(image, image, mask=roi_mask)
        
        end = time.time()
        # Only print timing for optimization frames
        if self.frame_count % self.optimization_interval == 0:
            print(f"Adaptive ROI computation time: {end - start:.4f} seconds")

        return masked_image, vanishing_point, roi_mask

    def hough_transform(self, edges):
        """Apply Hough Transform for line detection"""
        return cv2.HoughLinesP(
            edges,
            rho=self.rho,
            theta=self.theta,
            threshold=self.threshold,
            minLineLength=self.min_line_length,
            maxLineGap=self.max_line_gap
        )

    def line_validation(self, lines: np.ndarray, vanishing_point: tuple, 
                       image_shape: tuple, image: np.ndarray) -> list:
        """
        Validate detected lane candidates using geometric and color constraints
        
        Implements confidence scoring:
        Score(L) = w1*A(ρ,θ) + w2*Length(L) + w3*G_VP(L) + w4*C_color(L)
        """
        if len(lines) == 0:
            return []
        
        height, width = image_shape[:2]
        vx, vy = vanishing_point
        
        valid_lines = []
        
        for line in lines:
            x1, y1, x2, y2 = line
            
            # Calculate line length
            line_length = np.sqrt((x2 - x1)**2 + (y2 - y1)**2)
            
            # Skip very short lines
            if line_length < 50:
                continue
            
            # Check slope constraint
            if abs(x2 - x1) > 10:
                slope = (y2 - y1) / (x2 - x1)
                if not (-3 < slope < 3):
                    continue
            
            # Calculate distance to vanishing point
            a = y2 - y1
            b = -(x2 - x1)
            c = (x2 - x1) * y1 - (y2 - y1) * x1
            
            if a == 0 and b == 0:
                continue
            
            distance_to_vp = abs(a * vx + b * vy + c) / np.sqrt(a**2 + b**2)
            
            # Skip lines too far from vanishing point
            if distance_to_vp > 100:
                continue
            
            # Color scoring along the line
            num_samples = max(int(line_length // 10), 5)
            x_samples = np.linspace(x1, x2, num_samples).astype(int)
            y_samples = np.linspace(y1, y2, num_samples).astype(int)
            
            valid_samples = (x_samples >= 0) & (x_samples < width) & (y_samples >= 0) & (y_samples < height)
            x_samples = x_samples[valid_samples]
            y_samples = y_samples[valid_samples]
            
            if len(x_samples) > 0:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                color_score = np.mean(gray[y_samples, x_samples])
            else:
                color_score = 0
            
            # Confidence scoring
            w1, w2, w3, w4 = 0.3, 0.3, 0.2, 0.2
            accumulator_score = 1.0
            geometric_score = 1.0 / (1.0 + distance_to_vp / 50.0)
            
            confidence_score = (w1 * accumulator_score + 
                              w2 * (line_length / 100.0) + 
                              w3 * geometric_score + 
                              w4 * (color_score / 255.0))
            
            valid_lines.append((line, confidence_score))
        
        # Sort by confidence and return top candidates
        valid_lines.sort(key=lambda x: x[1], reverse=True)
        
        return [line for line, score in valid_lines[:10]]

    def kalman_tracking(self, detected_lines: List[Tuple[float, float, float]]) -> Tuple[Optional[Tuple[float, float]], Optional[Tuple[float, float]]]:
        """
        Temporal lane tracking with Kalman filtering
        
        Implements:
        - State vector: x_k = [m, c, ṁ, ċ]ᵀ
        - Prediction: x̂_k|k-1 = F * x̂_k-1|k-1
        - Update: Kalman gain and correction equations
        """
        if not detected_lines:
            return None, None
        
        # Separate lines into left and right candidates
        left_candidates = []
        right_candidates = []
        
        for rho, theta, confidence in detected_lines:
            if abs(np.sin(theta)) > 0.1:
                slope = -np.cos(theta) / np.sin(theta)
                intercept = rho / np.sin(theta)
                
                if slope < 0:
                    left_candidates.append((slope, intercept, confidence))
                else:
                    right_candidates.append((slope, intercept, confidence))
        
        # Process left lane
        left_lane = None
        if left_candidates:
            left_candidates.sort(key=lambda x: x[2], reverse=True)
            slope, intercept = left_candidates[0][:2]
            
            # Kalman prediction
            predicted = self.left_lane_kalman.predict()
            
            # Kalman update
            measurement = np.array([[slope], [intercept]], dtype=np.float32)
            corrected = self.left_lane_kalman.correct(measurement)
            
            left_lane = (float(corrected[0]), float(corrected[1]))
        
        # Process right lane
        right_lane = None
        if right_candidates:
            right_candidates.sort(key=lambda x: x[2], reverse=True)
            slope, intercept = right_candidates[0][:2]
            
            # Kalman prediction and update
            predicted = self.right_lane_kalman.predict()
            measurement = np.array([[slope], [intercept]], dtype=np.float32)
            corrected = self.right_lane_kalman.correct(measurement)
            
            right_lane = (float(corrected[0]), float(corrected[1]))
        
        return left_lane, right_lane

    def classify_lanes(self, lines, image_shape, vanishing_point):
        """Classify detected lines as left or right lanes"""
        if lines is None:
            return [], []

        height, width = image_shape[:2]
        left_lines = []
        right_lines = []
        image_center_x = width // 2

        for line in lines:
            x1, y1, x2, y2 = line[0]
            if abs(x2 - x1) < 10:
                continue
            
            slope = (y2 - y1) / (x2 - x1)
            if abs(slope) < self.min_lane_slope or abs(slope) > self.max_lane_slope:
                continue
            
            line_center_x = (x1 + x2) / 2
            
            if slope < 0 and line_center_x < image_center_x * 1.2:
                left_lines.append(line[0])
            elif slope > 0 and line_center_x > image_center_x * 0.8:
                right_lines.append(line[0])

            # Filter lines too close to center
            center_distance = abs(line_center_x - image_center_x)
            min_distance_from_center = width * 0.2
            if center_distance < min_distance_from_center:
                if slope < 0:
                    left_lines = [l for l in left_lines if not np.array_equal(l, line[0])]
                elif slope > 0:
                    right_lines = [l for l in right_lines if not np.array_equal(l, line[0])]

        # Validate and filter lines
        left_lines = self.line_validation(left_lines, vanishing_point, image_shape, image)
        right_lines = self.line_validation(right_lines, vanishing_point, image_shape, image)
        
        return left_lines, right_lines

    def lane_departure_warning(self, left_lines, right_lines, image_shape):
        """Analyze lane positions for departure warning"""
        height, width = image_shape[:2]

        if not left_lines and not right_lines:
            return "CRITICAL: NO LANES DETECTED"
        elif not left_lines:
            return "WARNING: LEFT LANE LOST - POTENTIAL DEPARTURE"
        elif not right_lines:
            return "WARNING: RIGHT LANE LOST - POTENTIAL DEPARTURE"
        else:
            return self.analyze_lane_departure(left_lines, right_lines, image_shape)

    def analyze_lane_departure(self, left_lines, right_lines, image_shape):
        """Advanced lane departure analysis based on vehicle position"""
        height, width = image_shape[:2]

        left_x_positions = []
        right_x_positions = []
        sample_y = height - height // 3

        # Calculate lane intersections at sample line
        for line in left_lines:
            x1, y1, x2, y2 = line
            if y1 != y2:
                x_at_sample = x1 + (x2 - x1) * (sample_y - y1) / (y2 - y1)
                if 0 <= x_at_sample <= width:
                    left_x_positions.append(x_at_sample)

        for line in right_lines:
            x1, y1, x2, y2 = line
            if y1 != y2:
                x_at_sample = x1 + (x2 - x1) * (sample_y - y1) / (y2 - y1)
                if 0 <= x_at_sample <= width:
                    right_x_positions.append(x_at_sample)

        if not left_x_positions and not right_x_positions:
            return "UNKNOWN: LANE POSITIONS UNCLEAR"

        # Calculate departure ratio
        if left_x_positions and right_x_positions:
            avg_left_x = np.mean(left_x_positions)
            avg_right_x = np.mean(right_x_positions)
            lane_center = (avg_left_x + avg_right_x) / 2
            vehicle_center = width / 2

            offset = vehicle_center - lane_center
            lane_width = avg_right_x - avg_left_x

            if lane_width > 0:
                departure_ratio = abs(offset) / (lane_width / 2)

                if departure_ratio > 0.7:
                    direction = "LEFT" if offset < 0 else "RIGHT"
                    return f"DANGER: {direction} DEPARTURE DETECTED ({departure_ratio:.1%})"
                elif departure_ratio > 0.4:
                    direction = "LEFT" if offset < 0 else "RIGHT"
                    return f"CAUTION: DRIFTING {direction} ({departure_ratio:.1%})"
                else:
                    return "SAFE: CENTERED IN LANE"

        return "SAFE: LANES DETECTED"

    def draw_lanes(self, image, left_lines, right_lines):
        """Draw detected lanes on image"""
        line_image = np.zeros_like(image)

        # Draw left lanes in red
        for i, line in enumerate(left_lines):
            x1, y1, x2, y2 = line
            thickness = 8 if i == 0 else 4
            cv2.line(line_image, (x1, y1), (x2, y2), (0, 0, 255), thickness)

        # Draw right lanes in green
        for i, line in enumerate(right_lines):
            x1, y1, x2, y2 = line
            thickness = 8 if i == 0 else 4
            cv2.line(line_image, (x1, y1), (x2, y2), (0, 255, 0), thickness)

        return cv2.addWeighted(image, 0.8, line_image, 1.0, 0)

    def process_image(self, image):
        """Main processing pipeline with genetic algorithm optimization"""
        if image is None or image.size == 0:
            print("❌ Error: Invalid input image")
            return None
            
        self.frame_count += 1
        
        try:
            # Run genetic algorithm optimization every 120th frame
            if (self.frame_count - self.last_optimization_frame) >= self.optimization_interval:
                self.optimize_canny_thresholds(image)
                self.last_optimization_frame = self.frame_count
            
            # Stage 1: Preprocessing with color enhancement
            gray, enhanced_gray, blur = self.preprocess_image(image)

            # Stage 2: Shadow mitigation (optional)
            # corrected_image, shadow_mask = self.shadow_mitigation_hsv(image)

            # Stage 3: Edge detection with optimized thresholds
            edges = self.canny_edge_detection(blur)

            # Stage 4: Adaptive ROI
            roi_edges, vanishing_point, roi_mask = self.region_of_interest(edges)

            # Stage 5: Line detection
            lines = self.hough_transform(roi_edges)

            # Stage 6: Lane classification and validation
            left_lines, right_lines = self.classify_lanes(lines, image.shape, vanishing_point)

            # Stage 7: Kalman tracking (convert lines to polar format if needed)
            # detected_lines_polar = self.convert_lines_to_polar(left_lines + right_lines)
            # tracked_left, tracked_right = self.kalman_tracking(detected_lines_polar)

            # Stage 8: Departure analysis
            warning = self.lane_departure_warning(left_lines, right_lines, image.shape)

            # Visualization
            result_image = self.draw_lanes(image, left_lines, right_lines)

            # Add status text with genetic algorithm info
            cv2.putText(result_image, warning, (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            cv2.putText(result_image, f"Left: {len(left_lines)}, Right: {len(right_lines)}",
                       (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
            cv2.putText(result_image, f"VP: ({vanishing_point[0]},{vanishing_point[1]})",
                       (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
            cv2.putText(result_image, f"Thresholds: {self.canny_low},{self.canny_high}",
                       (10, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 165, 0), 1)
            cv2.putText(result_image, f"Frame: {self.frame_count}",
                       (10, 150), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (128, 128, 128), 1)
            
            # Show genetic algorithm status
            frames_until_next_opt = self.optimization_interval - (self.frame_count - self.last_optimization_frame)
            cv2.putText(result_image, f"Next GA opt in: {frames_until_next_opt} frames",
                       (10, 180), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 100, 255), 1)

            return {
                'result': result_image,
                'original': image,
                'gray': gray,
                'enhanced': enhanced_gray,
                'edges': edges,
                'roi_edges': roi_edges,
                'roi_mask': roi_mask,
                'vanishing_point': vanishing_point,
                'left_lines': left_lines,
                'right_lines': right_lines,
                'warning': warning,
                'canny_thresholds': (self.canny_low, self.canny_high),
                'frame_count': self.frame_count
            }
            
        except Exception as e:
            print(f"❌ Error processing image: {e}")
            return None

    def process_video(self, video_path, output_path):
        """Process video with lane detection and genetic algorithm optimization"""
        if not video_path or not output_path:
            print("❌ Error: Invalid video paths provided")
            return
            
        cap = cv2.VideoCapture(video_path)
        
        if not cap.isOpened():
            print(f"❌ Error: Could not open video file: {video_path}")
            return

        fps = int(cap.get(cv2.CAP_PROP_FPS))
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        if fps <= 0 or width <= 0 or height <= 0:
            print("❌ Error: Invalid video properties")
            cap.release()
            return

        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

        print(f"🎬 Processing video: {total_frames} frames")
        print(f"🧬 Genetic optimization will run every {self.optimization_interval} frames")
        
        optimization_count = 0
        frame_count = 0
        
        while True:
            ret, frame = cap.read()
            if not ret:
                break

            result = self.process_image(frame)
            
            if result is not None:
                out.write(result['result'])

                frame_count += 1
                
                # Count optimizations
                if (frame_count - self.last_optimization_frame) == 0 and frame_count > 1:
                    optimization_count += 1
                
                # Progress reporting
                if frame_count % 100 == 0:
                    progress = (frame_count / total_frames) * 100
                    print(f"📊 Progress: {progress:.1f}% ({frame_count}/{total_frames}) - Optimizations: {optimization_count}")
                
                # Show current thresholds during optimization frames
                if frame_count % self.optimization_interval == 0:
                    print(f"🎯 Current Canny thresholds: Low={self.canny_low}, High={self.canny_high}")
            else:
                print(f"⚠️  Skipping frame {frame_count} due to processing error")

        cap.release()
        out.release()
        
        print(f"✅ Enhanced lane detection video saved: {output_path}")
        print(f"🧬 Total genetic algorithm optimizations: {optimization_count}")
        print(f"📈 Final optimized thresholds: Low={self.canny_low}, High={self.canny_high}")

    def process_realtime_camera(self, camera_index=0):
        """Process real-time camera feed with genetic algorithm optimization"""
        cap = cv2.VideoCapture(camera_index)
        
        if not cap.isOpened():
            print("❌ Error: Could not open camera")
            return
        
        print("🎥 Starting real-time lane detection with genetic algorithm optimization")
        print("📋 Controls:")
        print("   - Press 'q' to quit")
        print("   - Press 'o' to force optimization")
        print("   - Press 'r' to reset thresholds to default")
        
        while True:
            ret, frame = cap.read()
            if not ret:
                print("❌ Error: Could not read frame")
                break
            
            # Process frame
            result = self.process_image(frame)
            
            # Display result
            cv2.imshow('Enhanced Lane Detection with Genetic Algorithm', result['result'])
            
            # Handle key presses
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('o'):
                print("🧬 Manual optimization triggered...")
                self.optimize_canny_thresholds(frame)
            elif key == ord('r'):
                print("🔄 Resetting thresholds to default...")
                self.canny_low = 50
                self.canny_high = 150
                print(f"   Reset to: Low={self.canny_low}, High={self.canny_high}")
        
        cap.release()
        cv2.destroyAllWindows()
        print(f"🏁 Session ended. Final thresholds: Low={self.canny_low}, High={self.canny_high}")


# Usage example
